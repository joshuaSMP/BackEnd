package com.product.api.entity;

public interface ProductBasicData {
    
    Integer getProduct_id();

    String getGtin();
    
    String getProduct();
    
    Double getPrice();
}
