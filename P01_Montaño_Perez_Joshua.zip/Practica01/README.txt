Montaño Pérez Joshua Said 
317222812

Se compilan los archivos estando en la carpeta src:
java *.java

Se corre con el comando 
java Main.java 

